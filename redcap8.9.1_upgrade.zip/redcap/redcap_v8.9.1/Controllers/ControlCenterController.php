<?php

class ControlCenterController extends Controller
{
	// Render the Find Calculation Errors page
	public function findCalcErrors()
	{
		if (!SUPER_USER) exit('ERROR'); // Super users only
		global $isAjax;
		if ($isAjax && isset($_GET['pid']) && $_GET['action'] == 'findErrors') {
			ControlCenter::findCalcErrorsSingleProject();
		} elseif ($isAjax && $_GET['action'] == 'contactUsers' && isset($_POST['projectsUsers']) && strlen($_POST['projectsUsers']) > 0) {
			ControlCenter::findCalcErrorsEmailUsers();
		} else {
			$GLOBALS['project_ids'] = ControlCenter::findCalcErrorsGetProjectList($_GET['includeDevProjects']);
			$this->render('ControlCenter/findCalcErrors.php', $GLOBALS);
		}
	}
	
	// Perform the One-Click Upgrade
	public function oneClickUpgrade()
	{
		if (!SUPER_USER) exit('ERROR'); // Super users only
		Upgrade::performOneClickUpgrade();
	}
	
	// Execute the upgrade SQL script to complete an upgrade
	public function executeUpgradeSQL()
	{
		if (!SUPER_USER) exit('ERROR'); // Super users only
		print Upgrade::executeUpgradeSQL($_POST['version']);
	}
	
	// Execute the upgrade SQL script to complete an upgrade
	public function autoFixTables()
	{
		// Super users only
		print ((SUPER_USER && Upgrade::autoFixTables()) ? '1' : '0');
	}
	
	// Hide the Easy Upgrade box on the main Control Center page
	public function hideEasyUpgrade()
	{
		// Super users only
		print ((SUPER_USER && Upgrade::hideEasyUpgrade($_POST['hide'])) ? '1' : '0');
	}
}